<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{ asset('assets/css/cosmo.min.css') }}">
    <title>METODE SAW</title>
</head>
<body>
    <nav class="navbar navbar-inverse navbar-static-top">
        <div class="container">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li><a href="{{ url('/home') }}">HOME</a></li>
                    <li><a href="{{ url('/alternatif') }}">ALTERNATIF</a></li>
                    <li><a href="{{ url('/kriteria') }}">KRITERIA</a></li>
                    <li><a href="{{ url('/nilai') }}">NILAI</a></li>
                    <li><a href="{{ url('/metode') }}">METODE SAW</a></li>
                    <li><a href="{{ url('/hasil') }}">HASIL ANALISA</a></li>
                    <li><a href="{{ url('/logout') }}">LOGOUT</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        @yield('content')
    </div>
</body>
</html>
