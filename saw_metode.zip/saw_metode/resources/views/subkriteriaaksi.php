@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <ol class="breadcrumb">
            <h4>SUBKRITERIA / {{ $action == 'tambah' ? 'TAMBAH DATA' : 'UBAH DATA' }}</h4>
        </ol>
    </div>
    <div class="panel panel-container">
        <div class="bootstrap-table">
            <form action="{{ $action == 'tambah' ? route('subkriteria.store') : route('subkriteria.update', $subkriteria->id_subkriteria) }}" method="post">
                @csrf
                @if($action == 'ubah')
                    @method('PUT')
                @endif
                <input type="hidden" name="id_kriteria" value="{{ $id_kriteria }}">
                <div class="form-group">
                    <label>Nama Subkriteria</label>
                    <input type="text" name="nama_subkriteria" class="form-control" placeholder="Nama Subkriteria" value="{{ $subkriteria->nama_subkriteria ?? '' }}">
                </div>
                <div class="form-group">
                    <label>Nilai Subkriteria</label>
                    <input type="number" name="nilai_subkriteria" class="form-control" placeholder="Nilai Subkriteria" value="{{ $subkriteria->nilai_subkriteria ?? '' }}">
                </div>
                
                <div class="modal-footer">
                    <a href="{{ route('subkriteria.index', ['id_kriteria' => $id_kriteria]) }}" class="btn btn-primary">KEMBALI</a>
                    <input type="submit" class="btn btn-success" value="{{ $action == 'tambah' ? 'SIMPAN' : 'UBAH' }}">
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
