@extends('app')

@section('content')
    <div style="max-width: 800px; margin: 40px auto; padding: 20px; background-color: #f9f9f9; border: 1px solid #ddd; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
        <h2 style="font-size: 24px; font-weight: bold; margin-bottom: 10px;">Perhitungan SAW untuk Rekomendasi Pemilihan Kendaraan</h2>
        <p style="font-size: 16px; color: #666; margin-bottom: 20px;">Berikut adalah perhitungan SAW untuk rekomendasi pemilihan kendaraan</p>
    </div>
@endsection