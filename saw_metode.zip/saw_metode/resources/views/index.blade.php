@extends('layouts.app')

@section('content')
<div class="container">
    <center>
        <h3>
            SELAMAT DATANG METODE SAW
        </h3>
    </center>
</div>
@endsection
