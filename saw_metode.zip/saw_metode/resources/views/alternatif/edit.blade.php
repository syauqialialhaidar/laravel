@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <h4>ALTERNATIF / UBAH DATA</h4>
    </div>
    <div class="panel panel-container">
        <div class="bootstrap-table">
            <form action="{{ route('alternatif.update', $alternatif->id_alternatif) }}" method="post">
                @csrf
                @method('PUT')
                <input type="hidden" name="id_alternatif" value="{{ $alternatif->id_alternatif }}">
                <div class="form-group">
                    <label>Nama Alternatif</label>
                    <input type="text" name="nama_alternatif" class="form-control" placeholder="nama alternatif" value="{{ $alternatif->nama_alternatif }}">
                </div>
                <div class="modal-footer">
                    <a href="{{ route('alternatif.index') }}" class="btn btn-primary">KEMBALI</a>
                    <input type="submit" class="btn btn-success" value="UBAH">
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
