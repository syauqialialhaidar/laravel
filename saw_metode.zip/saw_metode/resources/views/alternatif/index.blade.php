@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <h4>ALTERNATIF</h4>
    </div>

    <div class="panel panel-container">
        <div class="bootstrap-table">
            <a href="{{ route('alternatif.create') }}" class="btn btn-primary">TAMBAH DATA</a>
            <hr>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">Nama Alternatif</th>
                            <th class="text-center">Nilai SAW</th>
                            <th class="text-center">Rangking</th>
                            <th class="text-center">Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($alternatifs as $key => $alternatif)
                        <tr>
                            <td class="text-center">{{ $key + 1 }}</td>
                            <td class="text-center">{{ $alternatif->nama_alternatif }}</td>
                            <td class="text-center">{{ number_format($alternatif->nilai_saw, 3) }}</td>
                            <td class="text-center">{{ $alternatif->rangking }}</td>
                            <td class="text-center">
                                <a href="{{ route('alternatif.edit', $alternatif->id_alternatif) }}" class="btn btn-success">UBAH</a>
                                <form action="{{ route('alternatif.destroy', $alternatif->id_alternatif) }}" method="post" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">HAPUS</button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
