@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <h4>KRITERIA/ {{ isset($kriteria) ? 'UBAH DATA' : 'TAMBAH DATA' }}</h4>
    </div>

    <div class="panel panel-container">
        <div class="bootstrap-table">
            <form action="{{ isset($kriteria) ? route('kriteria.update', $kriteria->id_kriteria) : route('kriteria.store') }}" method="post">
                @csrf
                @if(isset($kriteria))
                    @method('PUT')
                @endif
                <div class="form-group">
                    <label>Nama Kriteria</label>
                    <input type="text" name="nama_kriteria" class="form-control" placeholder="nama kriteria" value="{{ $kriteria->nama_kriteria ?? '' }}">
                </div>
                <div class="form-group">
                    <label>Bobot Kriteria</label>
                    <input type="number" name="bobot_kriteria" class="form-control" placeholder="0" value="{{ $kriteria->bobot_kriteria ?? '' }}">
                </div>
                <div class="form-group">
                    <label>Tipe Kriteria</label>
                    <select name="tipe_kriteria" class="form-control">
                        <option {{ isset($kriteria) && $kriteria->tipe_kriteria == 'Benefit' ? 'selected' : '' }}>Benefit</option>
                        <option {{ isset($kriteria) && $kriteria->tipe_kriteria == 'Cost' ? 'selected' : '' }}>Cost</option>
                    </select>
                </div>
                <div class="modal-footer">
                    <a href="{{ route('kriteria.index') }}" class="btn btn-primary">KEMBALI</a>
                    <input type="submit" class="btn btn-success" value="{{ isset($kriteria) ? 'UBAH' : 'SIMPAN' }}">
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
