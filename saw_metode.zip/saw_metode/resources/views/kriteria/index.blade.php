@extends('layout.app')

@section('content')
<div class="container">
    <div class="row">
        <ol class="breadcrumb"><h4>KRITERIA</h4></ol>
    </div>

    <div class="panel panel-container">
        <div class="bootstrap-table">
            <a href="{{ route('kriteria.create') }}" class="btn btn-primary">TAMBAH DATA</a>
            <hr>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">Nama Kriteria</th>
                            <th class="text-center">Bobot</th>
                            <th class="text-center">Tipe</th>
                            <th class="text-center">Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($kriterias as $kriteria)
                        <tr>
                            <td class="text-center">{{ $loop->iteration }}</td>
                            <td class="text-center">{{ $kriteria->nama_kriteria }}</td>
                            <td class="text-center">{{ $kriteria->bobot_kriteria }}</td>
                            <td class="text-center">{{ $kriteria->tipe_kriteria }}</td>
                            <td class="text-center">
                                <a href="{{ route('kriteria.edit', $kriteria->id) }}" class="btn btn-success">UBAH</a>
                                <form action="{{ route('kriteria.destroy', $kriteria->id) }}" method="POST" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">HAPUS</button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
