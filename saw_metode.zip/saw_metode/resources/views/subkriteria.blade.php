@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <ol class="breadcrumb">
                <h4>SUBKRITERIA / <a href="{{ url('/kriteria') }}">{{ $kriteria->nama_kriteria }}</a></h4>
            </ol>
        </div>

        <div class="panel panel-container">
            <div class="bootstrap-table">
                <a href="{{ url('/subkriteria/create', $id_kriteria) }}" class="btn btn-primary">TAMBAH DATA</a>
                <hr>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Nama Subkriteria</th>
                                <th class="text-center">Nilai</th>
                                <th class="text-center">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($subkriteria as $no => $sub)
                                <tr>
                                    <td class="text-center">{{ $no + 1 }}</td>
                                    <td class="text-center">{{ $sub->nama_subkriteria }}</td>
                                    <td class="text-center">{{ $sub->nilai_subkriteria }}</td>
                                    <td class="text-center">
                                        <a href="{{ url('/subkriteria/edit', ['id_kriteria' => $id_kriteria, 'id_subkriteria' => $sub->id_subkriteria]) }}" class="btn btn-success">UBAH</a>
                                        <a href="{{ url('/subkriteria/delete', ['id_kriteria' => $id_kriteria, 'id_subkriteria' => $sub->id_subkriteria]) }}" class="btn btn-danger">HAPUS</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
