@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <ol class="breadcrumb">
                <h4>METODE</h4>
            </ol>
        </div>

        <div class="panel panel-container">
            <div class="bootstrap-table">
                <h4>Nilai Keputusan</h4>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Nama Alternatif</th>
                                @foreach ($kriterias as $kriteria)
                                    <th class="text-center">{{ $kriteria->nama_kriteria }}</th>
                                @endforeach
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($alternatifs as $index => $alternatif)
                                <tr>
                                    <td class="text-center">{{ $index + 1 }}</td>
                                    <td class="text-center">{{ $alternatif->nama_alternatif }}</td>
                                    @foreach ($kriterias as $kriteria)
                                        <td class="text-center">
                                            {{-- Masukkan nilai subkriteria di sini --}}
                                            {{ $nilai[$index][$kriteria->id_kriteria] }}
                                        </td>
                                    @endforeach
                                </tr>
                            @endforeach
                            <tr>
                                <td colspan="2">Nilai Max</td>
                                @foreach ($kriterias as $kriteria)
                                    <td class="text-center"><b>{{ $max[$kriteria->id_kriteria] }}</b></td>
                                @endforeach
                            </tr>
                            <tr>
                                <td colspan="2">Nilai Min</td>
                                @foreach ($kriterias as $kriteria)
                                    <td class="text-center"><b>{{ $min[$kriteria->id_kriteria] }}</b></td>
                                @endforeach
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            {{-- Masukkan bagian-bagian lainnya seperti Konversi Nilai, Normalisasi, Normalisasi Bobot, dll. --}}
        </div>
    </div>
@endsection
