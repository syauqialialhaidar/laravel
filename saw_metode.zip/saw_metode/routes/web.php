<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AlternatifController;
use App\Http\Controllers\KriteriaController;
use App\Http\Controllers\SubkriteriaController;

Route::prefix('subkriteria')->group(function () {
    Route::get('/{id_kriteria}', [SubkriteriaController::class, 'index'])->name('subkriteria.index');
    Route::get('/create/{id_kriteria}', [SubkriteriaController::class, 'create'])->name('subkriteria.create');
    Route::post('/store', [SubkriteriaController::class, 'store'])->name('subkriteria.store');
    Route::get('/edit/{id_kriteria}/{id_subkriteria}', [SubkriteriaController::class, 'edit'])->name('subkriteria.edit');
    Route::put('/update/{id_subkriteria}', [SubkriteriaController::class, 'update'])->name('subkriteria.update');
    Route::delete('/destroy/{id_kriteria}/{id_subkriteria}', [SubkriteriaController::class, 'destroy'])->name('subkriteria.destroy');
});


Route::resource('kriteria', KriteriaController::class);


Route::delete('/alternatif/{id}', [AlternatifController::class, 'destroy'])->name('alternatif.destroy');
Route::get('/alternatif', [AlternatifController::class, 'index'])->name('alternatif.index');
Route::get('/alternatif/create', [AlternatifController::class, 'create'])->name('alternatif.create');
Route::post('/alternatif', [AlternatifController::class, 'store'])->name('alternatif.store');
Route::get('/alternatif/{id}/edit', [AlternatifController::class, 'edit'])->name('alternatif.edit');
Route::put('/alternatif/{id}', [AlternatifController::class, 'update'])->name('alternatif.update');
Route::delete('/alternatif/{id}', [AlternatifController::class, 'destroy'])->name('alternatif.destroy');
Route::get('/alternatif', [AlternatifController::class, 'index'])->name('alternatif.index');

Route::get('/', function () {
    return view('welcome');
});
