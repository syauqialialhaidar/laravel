<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kriteria;
use App\Models\Subkriteria;

class SubkriteriaController extends Controller
{
    public function index($id_kriteria)
    {
        $kriteria = Kriteria::findOrFail($id_kriteria);
        $subkriterias = Subkriteria::where('id_kriteria', $id_kriteria)->orderBy('id_subkriteria')->get();
        return view('subkriteria', compact('kriteria', 'subkriterias'));
    }

    public function create($id_kriteria)
    {
        return view('subkriteriaaksi', ['id_kriteria' => $id_kriteria, 'action' => 'tambah']);
    }

    public function store(Request $request)
    {
        $subkriteria = new Subkriteria;
        $subkriteria->id_kriteria = $request->id_kriteria;
        $subkriteria->nama_subkriteria = $request->nama_subkriteria;
        $subkriteria->nilai_subkriteria = $request->nilai_subkriteria;
        $subkriteria.save();

        return redirect()->route('subkriteria.index', ['id_kriteria' => $request->id_kriteria]);
    }

    public function edit($id_kriteria, $id_subkriteria)
    {
        $subkriteria = Subkriteria::findOrFail($id_subkriteria);
        return view('subkriteriaaksi', ['id_kriteria' => $id_kriteria, 'subkriteria' => $subkriteria, 'action' => 'ubah']);
    }

    public function update(Request $request, $id_subkriteria)
    {
        $subkriteria = Subkriteria::findOrFail($id_subkriteria);
        $subkriteria->nama_subkriteria = $request->nama_subkriteria;
        $subkriteria->nilai_subkriteria = $request->nilai_subkriteria;
        $subkriteria.save();

        return redirect()->route('subkriteria.index', ['id_kriteria' => $request->id_kriteria]);
    }

    public function destroy($id_kriteria, $id_subkriteria)
    {
        $subkriteria = Subkriteria::findOrFail($id_subkriteria);
        $subkriteria->delete();

        return redirect()->route('subkriteria.index', ['id_kriteria' => $id_kriteria]);
    }
}
?>
