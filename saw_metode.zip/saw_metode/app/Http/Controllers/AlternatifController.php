<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AlternatifController extends Controller
{
    // Menampilkan daftar alternatif
    public function index()
    {
        $alternatifs = DB::table('tbl_alternatif')->orderBy('id_alternatif')->get();
        return view('alternatif.index', ['alternatifs' => $alternatifs]);
    }

    // Menampilkan form untuk menambah data alternatif
    public function create()
    {
        return view('alternatif.create');
    }

    // Menyimpan data alternatif baru
    public function store(Request $request)
    {
        DB::table('tbl_alternatif')->insert([
            'nama_alternatif' => $request->nama_alternatif,
            'nilai_saw' => 0,
            'rangking' => 0
        ]);
        return redirect()->route('alternatif.index');
    }

    // Menampilkan form untuk mengubah data alternatif
    public function edit($id)
    {
        $alternatif = DB::table('tbl_alternatif')->where('id_alternatif', $id)->first();
        return view('alternatif.edit', ['alternatif' => $alternatif]);
    }

    // Mengubah data alternatif
    public function update(Request $request, $id)
    {
        DB::table('tbl_alternatif')->where('id_alternatif', $id)->update([
            'nama_alternatif' => $request->nama_alternatif
        ]);
        return redirect()->route('alternatif.index');
    }

    // Menghapus data alternatif
    public function destroy($id)
    {
        DB::table('tbl_alternatif')->where('id_alternatif', $id)->delete();
        return redirect()->route('alternatif.index');
    }
}