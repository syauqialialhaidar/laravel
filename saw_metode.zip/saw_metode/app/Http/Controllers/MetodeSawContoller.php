<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MetodeSawController extends Controller
{
    public function index()
    {
        // Ambil data alternatif
        $alternatifs = DB::table('tbl_alternatif')->orderBy('id_alternatif')->get();

        // Ambil data kriteria
        $kriterias = DB::table('tbl_kriteria')->orderBy('id_kriteria')->get();

        // Ambil nilai subkriteria untuk setiap alternatif dan kriteria
        $nilai = [];
        foreach ($alternatifs as $alternatif) {
            foreach ($kriterias as $kriteria) {
                $query = DB::table('tbl_subkriteria as s')
                            ->join('tbl_nilai as b', 's.id_subkriteria', '=', 'b.id_subkriteria')
                            ->where('b.id_alternatif', $alternatif->id_alternatif)
                            ->where('b.id_kriteria', $kriteria->id_kriteria)
                            ->select('s.nama_subkriteria')
                            ->orderBy('b.id_kriteria')
                            ->first();
                $nilai[$alternatif->id_alternatif][$kriteria->id_kriteria] = $query ? $query->nama_subkriteria : '-';
            }
        }

        // Hitung nilai maksimum dan minimum
        $max = [];
        $min = [];
        foreach ($kriterias as $kriteria) {
            $max[$kriteria->id_kriteria] = DB::table('tbl_subkriteria as s')
                                            ->join('tbl_nilai as b', 's.id_subkriteria', '=', 'b.id_subkriteria')
                                            ->where('b.id_kriteria', $kriteria->id_kriteria)
                                            ->max('s.nilai_subkriteria');
            $min[$kriteria->id_kriteria] = DB::table('tbl_subkriteria as s')
                                            ->join('tbl_nilai as b', 's.id_subkriteria', '=', 'b.id_subkriteria')
                                            ->where('b.id_kriteria', $kriteria->id_kriteria)
                                            ->min('s.nilai_subkriteria');
        }

        return view('metode_saw', compact('alternatifs', 'kriterias', 'nilai', 'max', 'min'));
    }
}
